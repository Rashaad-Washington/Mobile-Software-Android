package com.example.assignment5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.example.assignment5.databinding.ActivityMainBinding

// Rashaad Washington
// CSCI 4010
// Assignment 5

const val FILENAME = "word-code-for-assigment.txt"
class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val wordList = mutableListOf<String>()
    private var word = ""
    private var counter : Int = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val button1 = findViewById<Button>(R.id.button1)
        val button2 = findViewById<Button>(R.id.button1)
        val button3 = findViewById<Button>(R.id.button1)
        val button4 = findViewById<Button>(R.id.button1)

        binding.buttonStart.setOnClickListener { StartGame() }
        binding.buttonGiveup.setOnClickListener { GiveUp() }
        binding.buttonCheck.setOnClickListener { Check() }
        binding.button1.setOnClickListener {Assign(button1)}
        binding.button2.setOnClickListener {Assign(button2)}
        binding.button3.setOnClickListener {Assign(button3)}
        binding.button4.setOnClickListener {Assign(button4)}
    }

    private fun Assign(thisButton : Button) {
        if (findViewById<EditText>(R.id.userInput).getText().toString() == ""){
            findViewById<TextView>(R.id.infoBoard).setText("Whoops! Missing a letter!")
        } else if (findViewById<EditText>(R.id.userInput).getText().toString().length > 2 ){
            findViewById<TextView>(R.id.infoBoard).setText("Whoops! More than one letter!")
        } //else if (findViewById<EditText>(R.id.userInput).getText().ts){
        else {
            thisButton.setText(findViewById<EditText>(R.id.userInput).getText().toString())
            findViewById<EditText>(R.id.userInput).setText("")
            counter++
            findViewById<TextView>(R.id.infoBoard).setText("")
        }
    }

    private fun Correct(e : Button, num : Int) : Boolean {
        val test : String = e.getText().toString()
        return test.equals(word.get(num -1).toString(), ignoreCase = true)
    }

    private fun Win() : Boolean {
        if (Correct(findViewById<Button>(R.id.button1), 1) && Correct(findViewById<Button>(R.id.button2), 2) && Correct(findViewById<Button>(R.id.button3), 3) && Correct(findViewById<Button>(R.id.button4), 4)){
            findViewById<Button>(R.id.button1).isEnabled = true
            findViewById<Button>(R.id.button2).isEnabled = true
            findViewById<Button>(R.id.button3).isEnabled = true
            findViewById<Button>(R.id.button4).isEnabled = true
            findViewById<Button>(R.id.button_check).isEnabled = true
            findViewById<Button>(R.id.buttonGiveup).isEnabled = true
            findViewById<EditText>(R.id.userInput).isEnabled = true
            findViewById<Button>(R.id.buttonStart).isEnabled = true
            return true
        } else {
            return false
        }
    }

    private fun Check(){
        if (Win()) {
            findViewById<TextView>(R.id.infoBoard).setText("!!!You Win!!!\nIt took you $counter click(s)")
        } else {
            findViewById<TextView>(R.id.infoBoard).setText("Keep Trying")
            if (!Correct(findViewById<Button>(R.id.button1), 1)){
                findViewById<Button>(R.id.button1).setText("*")
            }
            if (!Correct(findViewById<Button>(R.id.button2), 2)){
                findViewById<Button>(R.id.button2).setText("*")
            }
            if (!Correct(findViewById<Button>(R.id.button3), 3)){
                findViewById<Button>(R.id.button3).setText("*")
            }
            if (!Correct(findViewById<Button>(R.id.button4), 4)){
                findViewById<Button>(R.id.button4).setText("*")
            }
        }
    }
    override fun onStart(){
        super.onStart()
        readData()
    }

    private fun StartGame() {
        readData()
        var index = (0..wordList.size-1).random()
        word = wordList[index]
        Log.i("LETTER COUNT", wordList[0])
        findViewById<TextView>(R.id.infoBoard).setText("And so it begins...")
        findViewById<Button>(R.id.button1).isEnabled = true
        findViewById<Button>(R.id.button2).isEnabled = true
        findViewById<Button>(R.id.button3).isEnabled = true
        findViewById<Button>(R.id.button4).isEnabled = true
        findViewById<Button>(R.id.button_check).isEnabled = true
        findViewById<Button>(R.id.buttonGiveup).isEnabled = true
        findViewById<EditText>(R.id.userInput).isEnabled = true
        findViewById<Button>(R.id.buttonStart).isEnabled = false
    }

    private fun GiveUp(){
        findViewById<Button>(R.id.button1).setText(word.get(0).toString())
        findViewById<Button>(R.id.button2).setText(word.get(1).toString())
        findViewById<Button>(R.id.button3).setText(word.get(2).toString())
        findViewById<Button>(R.id.button4).setText(word.get(3).toString())
        findViewById<TextView>(R.id.infoBoard).setText("Quitter! \n The word was $word\n You gave up after trying $counter times")
        Win()
    }

    private fun readData(){
        wordList.clear()
        openFileInput(FILENAME).bufferedReader().useLines { lines ->
            // This part reads the data.  It is file-specific
            for (line in lines) {
                val x = line.toString()
                wordList.add(x)
            }
        }
    }

}