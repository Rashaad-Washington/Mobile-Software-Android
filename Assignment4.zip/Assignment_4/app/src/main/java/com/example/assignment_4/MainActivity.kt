package com.example.assignment_4

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import com.example.assignment_4.databinding.ActivityMainBinding
import kotlin.math.*

// Rashaad Washington
// CSCI 4010
// Assignment 4

class MainActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.editTextHistory.setOnClickListener(this)
        val buttonIds = listOf<Int>(
            R.id.button_add, R.id.button_subtract, R.id.button_multiply, R.id.button_divide,
            R.id.button_expo, R.id.button_cos, R.id.button_sin, R.id.button_tan, R.id.button_sqrt,
            R.id.button_log, R.id.button_lg, R.id.button_squared, R.id.button_clear
        )
        for (buttonID in buttonIds) {
            val button = binding.root.getViewById((buttonID))
            button.setOnClickListener(this)
        }
    }

    @SuppressLint("SetTextI18n")
    override fun onClick(v: View?) {
        val editX = findViewById<EditText>(R.id.editText_X)
        val editY = findViewById<EditText>(R.id.editText_Y)
        val editResult = findViewById<EditText>(R.id.editText_result)

        val inputX = editX.getText().toString()
        val inputY = editY.getText().toString()

        if (v?.getId() == R.id.button_clear) {
            editX.setText("")
            editY.setText("")
            editResult.setText("")
        } else if (v?.getId() == R.id.button_add) { //Addition
            if (inputX == "" || inputY == "") {
                editResult.setText("WARNING: field(s) are/is empty.")
            } else {
                val x: Float = inputX.toFloat()
                val y: Float = inputY.toFloat()
                val result: Float= x + y
                editResult.setText("" + result)
                binding.editTextHistory.append("${x} + ${y} = ${result} \n")
            }
        } else if (v?.getId() == R.id.button_subtract) {
            if (inputX == "" || inputY == "") {
                editResult.setText("WARNING: field(s) are/is empty.")
            } else {
                val x: Float = inputX.toFloat()
                val y: Float = inputY.toFloat()
                val result: Float = x - y
                editResult.setText("" + result)
                binding.editTextHistory.append("${x} - ${y} = ${result} \n")
            }
        } else if (v?.getId() == R.id.button_multiply) {
            if (inputX == "" || inputY == "") {
                editResult.setText("WARNING: field(s) are/is empty.")
            } else {
                val x: Float = inputX.toFloat()
                val y: Float = inputY.toFloat()
                val result: Float = x * y
                editResult.setText("" + result)
                binding.editTextHistory.append("${x} * ${y} = ${result} \n")
            }
        } else if (v?.getId() == R.id.button_divide) {
            if (inputX == "" || inputY == "") {
                editResult.setText("WARNING: field(s) are/is empty.")
            } else {
                val x: Float = inputX.toFloat()
                val y: Float = inputY.toFloat()
                val result: Float = x / y
                editResult.setText("" + result)
                binding.editTextHistory.append("${x} / ${y} = ${result} \n")
            }
        } else if (v?.getId() == R.id.button_expo) {
            if (inputX == "" || inputY == "") {
                editResult.setText("WARNING: field(s) are/is empty.")
            } else {
                val x: Float = inputX.toFloat()
                val y: Float = inputY.toFloat()
                val result: Float = x.pow(y)
                editResult.setText("" + result)
                binding.editTextHistory.append("${x} ^ ${y} = ${result} \n")
            }
        } else if (v?.getId() == R.id.button_cos) {
            if (inputX == "") {
                editResult.setText("WARNING: X field empty.")
            } else {
                val x: Float = inputX.toFloat()
                val result: Float = cos(x)
                editResult.setText("" + result)
                binding.editTextHistory.append("cos(${x}) = ${result} \n")
            }
        } else if (v?.getId() == R.id.button_sin) {
            if (inputX == "") {
                editResult.setText("WARNING: X field empty.")
            } else {
                val x: Float = inputX.toFloat()
                val result: Float = sin(x)
                editResult.setText("" + result)
                binding.editTextHistory.append("sin(${x}) = ${result} \n")
            }
        } else if (v?.getId() == R.id.button_tan) {
            if (inputX == "") {
                editResult.setText("WARNING: X field empty.")
            } else {
                val x: Float = inputX.toFloat()
                val result: Float = tan(x)
                editResult.setText("" + result)
                binding.editTextHistory.append("tan(${x}) = ${result} \n")
            }
        } else if (v?.getId() == R.id.button_sqrt) {
            if (inputX == "") {
                editResult.setText("WARNING: X field empty.")
            } else {
                val x: Float = inputX.toFloat()
                val result: Float = sqrt(x)
                editResult.setText("" + result)
                binding.editTextHistory.append("sqrt(${x}) = ${result} \n")
            }
        } else if (v?.getId() == R.id.button_log) {
            if (inputX == "") {
                editResult.setText("WARNING: X field empty.")
            } else {
                val x: Float = inputX.toFloat()
                val result: Float = log10(x)
                editResult.setText("" + result)
                binding.editTextHistory.append("log(${x}) = ${result} \n")
            }
        } else if (v?.getId() == R.id.button_lg) {
            if (inputX == "") {
                editResult.setText("WARNING: X field empty.")
            } else {
                val x: Float = inputX.toFloat()
                val result: Float = log2(x)
                editResult.setText("" + result)
                binding.editTextHistory.append("lg(${x}) = ${result} \n")
            }
        } else if (v?.getId() == R.id.button_squared) {
            if (inputX == "") {
                editResult.setText("WARNING: X field empty.")
            } else {
                val x: Float = inputX.toFloat()
                val result: Float = x.pow(2)
                editResult.setText("" + result)
                binding.editTextHistory.append("(${x})^2 = ${result} \n")
            }
        }
    }
}