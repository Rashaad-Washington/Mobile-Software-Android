package com.example.assignment6
//Rashaad Washington
// Assignment 6
// CSCI 4010
// December 2, 2021
import android.content.DialogInterface
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import com.example.assignment6.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.mapIt.setOnClickListener{
            val streetNum = findViewById<EditText>(R.id.editText_streetNum).text.toString()
            val streetName = findViewById<EditText>(R.id.editText_streetName).text.toString()
            val city = findViewById<EditText>(R.id.editText_city).text.toString()
            val state = findViewById<EditText>(R.id.editText_state).text.toString()
            val space = " "
            val comma = ","
            val address = streetNum + space + streetName.trim() + comma + space + city.trim() + comma + space + state.trim()
            showOnMap(address)
        }

        binding.reset.setOnClickListener {
            ResetListener()
        }
    }
        private fun ResetListener() {
            val builder = AlertDialog.Builder(binding.root.context)
            val listener = object : DialogInterface.OnClickListener{
                override fun onClick(dialog: DialogInterface?, which: Int) {
                    if (which == DialogInterface.BUTTON_POSITIVE){
                        binding.editTextStreetNum.setText("")
                        binding.editTextStreetName.setText("")
                        binding.editTextCity.setText("")
                        binding.editTextState.setText("")
                    }
                }

            }
            builder
                .setTitle(R.string.confirm)
                .setMessage(R.string.confirm_message)
                .setIcon(R.drawable.ic_dialog_question)
                .setPositiveButton(android.R.string.ok, listener)
                .setNegativeButton(android.R.string.cancel, listener)
                .show()

        }

    //show a location on a map
    // using an implicit intent
    private fun showOnMap(location : String) {
        val streetNum = findViewById<EditText>(R.id.editText_streetNum).text.toString()
        val streetName = findViewById<EditText>(R.id.editText_streetName).text.toString()
        val city = findViewById<EditText>(R.id.editText_city).text.toString()
        val state = findViewById<EditText>(R.id.editText_state).text.toString()

        if (streetNum.trim().length == 0 || streetName.trim().length == 0 || city.trim().length == 0 || state.trim().length == 0){
            val builder = AlertDialog.Builder(binding.root.context)
            builder
                .setTitle(R.string.warning)
                .setMessage(R.string.warning_message)
                .setIcon(R.drawable.ic_dialog_warning)
                .setPositiveButton(android.R.string.ok, null)
                .show()
        } else {
            val encodedLocation = Uri.encode(location)
            Log.i("Encoded Location", encodedLocation)

            val uriString = "geo:0,0?q=" + encodedLocation
            val uri = Uri.parse(uriString)
            val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
        }

    }
}